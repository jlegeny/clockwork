/**
	jQuery Task Organiser plugin
	Dual licensed under the MIT and GPL licenses
	
	@author Jozef Legény
	@version 0.1
	@homepage http://clockwork.fr/p/jquery/torg
	
	Uses jQuery JavaScript Library v1.3.2
	http://jquery.com/
*/
(function($) {
	$.fn.torg = function(settings) {
		
	var db;
	
	var config = { 'dbname' : 'torgDB' };
	
 	if (settings) $.extend(config, settings);
	
	return this.each( function() {
		$(this).css({
			'position' : 'relative',
			'padding' : '0'
		});
	
		$(this).html(
		'<p><a id="torg-newTask" class="ui-button ui-state-default ui-corner-all"><span class="ui-icon ui-icon-note"></span>New Task</a> ' + 
		'<a id="torg-saveTasks" class="ui-button ui-state-default ui-corner-all"><span class="ui-icon ui-icon-disk"></span>Save Tasks</a> ' +
		'<a id="torg-resetDB" class="ui-button ui-state-default ui-corner-all"><span class="ui-icon ui-icon-closethick"></span>Reset Database</a></p>' +
		'<div class="torg-quad"><div class="torg-icon torg-icon-important"></div><div class="torg-icon torg-icon-urgent"></div><ul id="torg-tasklist-IU"></ul></div>' +
		'<div class="torg-quad"><div class="torg-icon torg-icon-urgent"></div><ul id="torg-tasklist-I"></ul></div>' +
		'<div class="torg-quad"><div class="torg-icon torg-icon-important"></div><ul id="torg-tasklist-U"></ul></div>' +
		'<div class="torg-quad"><ul id="torg-tasklist-"></ul></div>');
		
		var t_height = $(this).height() - $(this).children('div:first').position().top;
		var t_width = $(this).width();
	
	
		$('.torg-quad').height((t_height) / 2).width((t_width - 7) / 2);
	
		$('.torg-quad .torg-icon').css({
			'top' : ((t_height - 128) / 4) + 'px',
			'left' : ((t_width - 128) / 4) + 'px'
		});

		$(this).find('.torg-quad:first .torg-icon-important').css({
			'left' : ((t_width - 128) / 4 - 32) + 'px'
		});
		$(this).find('.torg-quad:first .torg-icon-urgent').css({
			'left' : ((t_width - 128) / 4 + 32) + 'px'
		});

		$('#torg-newTask').click( torg_newTask );
		$('#torg-saveTasks').click( torg_saveChanges );
		$('#torg-resetDB').click( torg_resetDatabase );
	
		$('.torg-quad ul').sortable({ connectWith: '.torg-quad ul' });

		try 
		{
			if (window.openDatabase) 
			{
				db = openDatabase(config.dbname, "1.0", "CPDB", 200000);
				db.transaction(function(tx)
				{
					tx.executeSql(
						"SELECT task, important, urgent, done FROM torgTasks ORDER BY id DESC", 
						[], 
						function(tx, result) {
							for (var i = 0; i < result.rows.length; ++i)
							{
								var row = result.rows.item(i);
								torg_addTask(row.task, row.important == 'true', row.urgent == 'true', row.done == 'true');
							}
						}, 
						function(tx, error)
						{
							tx.executeSql("DROP TABLE IF EXISTS torgTasks");
							tx.executeSql("CREATE TABLE torgTasks (id INTEGER PRIMARY KEY, task TEXT, urgent BOOLEAN, important BOOLEAN, done BOOLEAN)", 
							[],
							function(result) {});
						});
				});
				if (!db)
					alert("Failed to open the database on disk.  This is probably because the version was bad or there is not enough space left in this domain's quota");
				
			}
			else
				alert("Couldn't open the database. Please try with a WebKit nightly with this feature enabled");
		}
		catch(err) 
		{
		}
		
		window.onbeforeunload = torg_saveChanges;

		function torg_newTask()
		{
			torg_addTask('New task', true, true, false);
		}
		
		function torg_resetDatabase()
		{
			if (confirm("Reset database ?"))
			{
				$('.torg-quad ul li').remove();
				db.transaction(function(tx)
				{
					tx.executeSql("DROP TABLE torgTasks");
					tx.executeSql("CREATE TABLE torgTasks (id INTEGER PRIMARY KEY, task TEXT, urgent BOOLEAN, important BOOLEAN, done BOOLEAN)", 
					[],
					function(result) {});
					
					
				});				
			}
			else
				return false;
		}

		/** Adds a new task to the list
		* @param text Text of the task to add
		* @param urgent True if the task is urgent
		* @param important True the task is important
		* @param done True if the task is finished
		*/

		function torg_addTask(text, urgent, important, done)
		{
			var tQuad = '#torg-tasklist-';
			
			if (urgent) tQuad += 'I';
			if (important) tQuad += 'U';

			var tLi = $('<li class="ui-widget-content"></li>')
				.append(
					$('<span>' + text + '</span>')
						.attr('contenteditable', true))		
				.append(
					$('<a class="ui-state-default"><span class="ui-icon ui-icon-trash"></span></a>')
						.click(function() { $(this).parent().remove(); })
				);

			
			if (done)
			{
				tLi.append($('<a class="torg-bDone ui-state-default"><span class="ui-icon ui-icon-circle-check"></span></a>')
					.click(function() {
						torg_markTaskAs($(this).parent(), false);
						return false;
					}))
					.addClass('torg-taskDone');
			}
			else
			{
				tLi.append($('<a class="torg-bDone ui-state-default"><span class="ui-icon ui-icon-check"></span></a>')
					.click(function() {
						torg_markTaskAs($(this).parent(), true);
						return false;
					}));
			}

			
			
			$(tQuad).prepend(tLi);
			return tLi;
		}

		function torg_markTaskAs(task, done)
		{
			if (done)
			{
				task.addClass('torg-taskDone');
				task.find('.torg-bDone span')
					.removeClass('ui-icon-check')
					.addClass('ui-icon-circle-check')
					
				task.find('.torg-bDone').unbind('click').click(function() {
						torg_markTaskAs($(this).parent(), false);
						return false;
					});
			}
			else
			{
				task.removeClass('torg-taskDone');
				task.find('.torg-bDone span')
					.removeClass('ui-icon-circle-check')
					.addClass('ui-icon-check')
					
					
				task.find('.torg-bDone').unbind('click').click(function() {
						torg_markTaskAs($(this).parent(), true);
						return false;
					});
			}
			return false;
		}

		function torg_saveChanges()
		{
			db.transaction(function (tx) 
			{
				// cleanup old tasks
				tx.executeSql("DELETE FROM torgTasks");
				
				// insert all current tasks
				var tasks = [];
				
				$('.torg-quad li').each( function() {
					var task = {
						task : $(this).children('span').text(),
						done : $(this).hasClass('.torg-taskDone'),
						important : ($(this).parent().attr('id').match('I') != null),
						urgent : ($(this).parent().attr('id').match('U') != null)
					}
					tasks.push(task);
				});
				
				for (var i in tasks)
				{
					var t = tasks[i];
					
					tx.executeSql("INSERT INTO torgTasks (task, important, urgent, done) VALUES (?, ?, ?, ?)", [t.task, t.important, t.urgent, t.done]);
				}
			});

		}
	});
 
	return this;
 
};
 
})(jQuery);
