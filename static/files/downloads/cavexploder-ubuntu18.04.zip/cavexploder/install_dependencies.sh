#!/bin/sh

apt install libsdl2-2.0.0 libsdl2-ttf-2.0.0 libsdl2-gfx-1.0.0
