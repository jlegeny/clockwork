#!/bin/sh

# URL : http://clockwork.fr

WRITERPATH="/Applications/iA Writer.app/Contents/Resources/English.lproj/"

cp backgroundPattern.png "$WRITERPATH"
cp tr-down-pattern.tiff "$WRITERPATH"
cp tr-up-pattern.tiff "$WRITERPATH"
