#!/bin/sh
BRANCHES=""
IGNORE=""

find . | sed 's/^..//' |  grep -E ".*\.cpp$|.*\.h$|.*\.hpp$" | grep -v -E "^scripts|local-tmp|^dist|tags|branches" | grep -v -E "$IGNORE" > OpenViBE.files
find . | sed 's/^..//' |  grep -E ".*\.cpp$|.*\.h$|.*\.hpp$" | grep -v -E "^scripts|local-tmp|^dist|tags" | grep -E "$BRANCHES" >> OpenViBE.files
find /usr/include -type d | grep -v -E "CEGUI|OGRE|boost|OIS" > OpenViBE.includes
find dist/include -type d >> OpenViBE.includes
find scripts/software/include -type d >> OpenViBE.includes

